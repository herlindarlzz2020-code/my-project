import React, { createContext, useEffect, useState } from "react";
export const AuthContext = createContext(null);
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  useEffect(()=>{ const s=localStorage.getItem("careerlync_user"); if(s) setUser(JSON.parse(s)); },[]);
  const login = (u) => { setUser(u); localStorage.setItem("careerlync_user", JSON.stringify(u)); };
  const logout = () => { setUser(null); localStorage.removeItem("careerlync_user"); };
  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
};