import React, { useContext } from "react";
import { Navbar, Nav, Container } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
const AppNavbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const out = () => { logout(); navigate("/login"); };
  return (<Navbar bg="dark" variant="dark" expand="lg">
    <Container>
      <Navbar.Brand as={Link} to="/">CareerLync</Navbar.Brand>
      <Navbar.Toggle aria-controls="nav" />
      <Navbar.Collapse id="nav">
        <Nav className="ms-auto">
          {!user && (<>
            <Nav.Link as={Link} to="/login">Login</Nav.Link>
            <Nav.Link as={Link} to="/register">Get Started</Nav.Link>
          </>)}
          {user && (<>
            {user.role==="Employer" && <Nav.Link as={Link} to="/employer">Employer</Nav.Link>}
            {user.role==="JobSeeker" && <Nav.Link as={Link} to="/jobseeker">Job Seeker</Nav.Link>}
            <Nav.Link onClick={out}>Logout</Nav.Link>
          </>)}
        </Nav>
      </Navbar.Collapse>
    </Container>
  </Navbar>);
};
export default AppNavbar;