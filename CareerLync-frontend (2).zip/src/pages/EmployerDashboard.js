import React, { useContext, useEffect, useState } from "react";
import { Container, Row, Col, Card, Form, Button, ListGroup, Modal } from "react-bootstrap";
import api from "../api";
import { AuthContext } from "../context/AuthContext";
const initialJob = { Title: "", Description: "", Location: "", Industry: "", ApplicationInstructions: "" };
const EmployerDashboard = () => {
  const { user } = useContext(AuthContext);
  const [jobs, setJobs] = useState([]);
  const [job, setJob] = useState(initialJob);
  const [editing, setEditing] = useState(null);
  const [show, setShow] = useState(false);
  const loadJobs = async () => { try { const res = await api.get("/Jobs"); setJobs(res.data || []);} catch {} };
  useEffect(()=>{ loadJobs(); }, []);
  const onChange = (e)=> setJob({ ...job, [e.target.name]: e.target.value });
  const submit = async (e)=>{ e.preventDefault();
    if (editing) await api.put(`/Jobs/${editing}`, { JobID: editing, EmployerUserID: user.id, ...job });
    else await api.post("/Jobs", { EmployerUserID: user.id, ...job });
    setJob(initialJob); setEditing(null); setShow(false); loadJobs();
  };
  const editJob = (j)=>{ setEditing(j.JobID || j.id); setJob({
    Title: j.Title || j.title || "", Description: j.Description || j.description || "",
    Location: j.Location || j.location || "", Industry: j.Industry || j.industry || "",
    ApplicationInstructions: j.ApplicationInstructions || j.applicationInstructions || ""
  }); setShow(true); };
  const remove = async (id)=>{ await api.delete(`/Jobs/${id}`); loadJobs(); };
  return (<Container className="mt-4">
    <Row>
      <Col md={5}>
        <Card className="mb-4"><Card.Body>
          <Card.Title>Post a Job</Card.Title>
          <Form onSubmit={submit}>
            <Form.Group className="mb-2"><Form.Label>Title</Form.Label>
              <Form.Control name="Title" value={job.Title} onChange={onChange} required /></Form.Group>
            <Form.Group className="mb-2"><Form.Label>Description</Form.Label>
              <Form.Control as="textarea" rows={3} name="Description" value={job.Description} onChange={onChange} /></Form.Group>
            <Form.Group className="mb-2"><Form.Label>Location</Form.Label>
              <Form.Control name="Location" value={job.Location} onChange={onChange} /></Form.Group>
            <Form.Group className="mb-3"><Form.Label>Industry</Form.Label>
              <Form.Control name="Industry" value={job.Industry} onChange={onChange} /></Form.Group>
            <Form.Group className="mb-3"><Form.Label>Application Instructions</Form.Label>
              <Form.Control name="ApplicationInstructions" value={job.ApplicationInstructions} onChange={onChange} /></Form.Group>
            <Button type="submit" variant="primary" className="w-100">{editing ? "Update Job" : "Post Job"}</Button>
          </Form>
        </Card.Body></Card>
      </Col>
      <Col md={7}>
        <Card><Card.Body>
          <Card.Title>Your Job Listings</Card.Title>
          <ListGroup>
            {jobs.map(j => (
              <ListGroup.Item key={j.JobID || j.id}>
                <div className="d-flex justify-content-between align-items-center">
                  <div><div className="fw-bold">{j.Title || j.title}</div>
                    <div className="text-muted small">{j.Location || j.location} {(j.Industry || j.industry) ? "• " + (j.Industry || j.industry) : ""}</div>
                  </div>
                  <div className="d-flex gap-2">
                    <Button size="sm" variant="outline-secondary" onClick={()=>editJob(j)}>Edit</Button>
                    <Button size="sm" variant="outline-danger" onClick={()=>remove(j.JobID || j.id)}>Delete</Button>
                  </div>
                </div>
              </ListGroup.Item>
            ))}
            {jobs.length===0 && <div className="text-center text-muted p-3">No jobs yet.</div>}
          </ListGroup>
        </Card.Body></Card>
      </Col>
    </Row>
    <Modal show={show} onHide={()=>setShow(false)}>
      <Modal.Header closeButton><Modal.Title>Edit Job</Modal.Title></Modal.Header>
      <Modal.Body>
        <Form onSubmit={submit}>
          <Form.Group className="mb-2"><Form.Label>Title</Form.Label>
            <Form.Control name="Title" value={job.Title} onChange={(e)=>setJob({...job, Title: e.target.value})} required /></Form.Group>
          <Form.Group className="mb-2"><Form.Label>Description</Form.Label>
            <Form.Control as="textarea" rows={3} name="Description" value={job.Description} onChange={(e)=>setJob({...job, Description: e.target.value})} /></Form.Group>
          <Form.Group className="mb-2"><Form.Label>Location</Form.Label>
            <Form.Control name="Location" value={job.Location} onChange={(e)=>setJob({...job, Location: e.target.value})} /></Form.Group>
          <Form.Group className="mb-2"><Form.Label>Industry</Form.Label>
            <Form.Control name="Industry" value={job.Industry} onChange={(e)=>setJob({...job, Industry: e.target.value})} /></Form.Group>
          <Form.Group className="mb-3"><Form.Label>Application Instructions</Form.Label>
            <Form.Control name="ApplicationInstructions" value={job.ApplicationInstructions} onChange={(e)=>setJob({...job, ApplicationInstructions: e.target.value})} /></Form.Group>
          <Button type="submit" variant="primary" className="w-100">Save</Button>
        </Form>
      </Modal.Body>
    </Modal>
  </Container>);
};
export default EmployerDashboard;