import React, { useState } from "react";
import { Container, Row, Col, Card, Form, Button, ToggleButtonGroup, ToggleButton, Alert } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import api from "../api";
const RegisterPage = () => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("JobSeeker");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault(); setError(""); setMessage("");
    try { await api.post("/Auth/register", { username, email, password, role });
      setMessage("Registration successful! Redirecting to login...");
      setTimeout(()=>nav("/login"), 800);
    } catch { setError("Registration failed"); }
  };
  return (<Container className="mt-5">
    <Row className="justify-content-center">
      <Col md={6}>
        <Card className="p-4">
          <h3 className="text-center mb-3">Create an account</h3>
          <div className="d-flex justify-content-center mb-3">
            <ToggleButtonGroup type="radio" name="roles" value={role} onChange={setRole}>
              <ToggleButton id="reg-js" value={"JobSeeker"}>Job Seeker</ToggleButton>
              <ToggleButton id="reg-em" value={"Employer"}>Employer</ToggleButton>
            </ToggleButtonGroup>
          </div>
          {message && <Alert variant="success">{message}</Alert>}
          {error && <Alert variant="danger">{error}</Alert>}
          <Form onSubmit={submit}>
            <Form.Group className="mb-3"><Form.Label>Username</Form.Label>
              <Form.Control value={username} onChange={(e)=>setUsername(e.target.value)} required /></Form.Group>
            <Form.Group className="mb-3"><Form.Label>Email</Form.Label>
              <Form.Control type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required /></Form.Group>
            <Form.Group className="mb-3"><Form.Label>Password</Form.Label>
              <Form.Control type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required /></Form.Group>
            <Button type="submit" variant="success" className="w-100">Register</Button>
          </Form>
        </Card>
      </Col>
    </Row>
  </Container>);
};
export default RegisterPage;