import React, { useContext, useEffect, useState } from "react";
import { Container, Row, Col, Card, Form, Button, Alert, InputGroup, ListGroup } from "react-bootstrap";
import api from "../api";
import { AuthContext } from "../context/AuthContext";
const JobSeekerDashboard = () => {
  const { user } = useContext(AuthContext);
  const [profile, setProfile] = useState({ FirstName: "", LastName: "", Phone: "", Qualification: "", Skills: "", IsActive: true });
  const [jobSeekerID, setJobSeekerID] = useState(null);
  const [msg, setMsg] = useState("");
  const [jobs, setJobs] = useState([]);
  const [query, setQuery] = useState("");
  useEffect(()=>{
    const load = async () => {
      try { const res = await api.get(`/JobSeekers/user/${user.id}`);
        if (res.data) { setJobSeekerID(res.data.JobSeekerID);
          setProfile({ FirstName: res.data.FirstName||"", LastName: res.data.LastName||"", Phone: res.data.Phone||"", Qualification: res.data.Qualification||"", Skills: res.data.Skills||"", IsActive: res.data.IsActive ?? true });
        } } catch {}
      try { const jobsRes = await api.get("/Jobs"); setJobs(jobsRes.data || []);} catch {}
    };
    if (user?.id) load();
  }, [user]);
  const onChange = (e)=> setProfile({ ...profile, [e.target.name]: e.target.value });
  const save = async (e)=>{
    e.preventDefault(); setMsg("");
    try {
      if (jobSeekerID) { await api.put(`/JobSeekers/${jobSeekerID}`, { JobSeekerID: jobSeekerID, UserID: user.id, ...profile }); setMsg("Profile updated successfully."); }
      else { const res = await api.post("/JobSeekers", { UserID: user.id, ...profile }); setJobSeekerID(res.data.JobSeekerID); setMsg("Profile created successfully."); }
    } catch { setMsg("Error saving profile."); }
  };
  const filtered = jobs.filter(j => !query ? true : (j.Title || "").toLowerCase().includes(query.toLowerCase()));
  const apply = async (job)=>{ try { await api.post("/Applications", { JobID: job.JobID || job.id, UserID: user.id }); alert("Applied successfully"); } catch { alert("Failed to apply"); } };
  return (<Container className="mt-4">
    <Row>
      <Col md={5}>
        <Card className="mb-4"><Card.Body>
          <Card.Title>My Profile</Card.Title>
          {msg && <Alert variant={msg.startsWith("Error") ? "danger" : "success"}>{msg}</Alert>}
          <Form onSubmit={save}>
            <Form.Group className="mb-2"><Form.Label>First Name</Form.Label>
              <Form.Control name="FirstName" value={profile.FirstName} onChange={onChange} required /></Form.Group>
            <Form.Group className="mb-2"><Form.Label>Last Name</Form.Label>
              <Form.Control name="LastName" value={profile.LastName} onChange={onChange} /></Form.Group>
            <Form.Group className="mb-2"><Form.Label>Phone</Form.Label>
              <Form.Control name="Phone" value={profile.Phone} onChange={onChange} /></Form.Group>
            <Form.Group className="mb-2"><Form.Label>Qualification</Form.Label>
              <Form.Control name="Qualification" value={profile.Qualification} onChange={onChange} /></Form.Group>
            <Form.Group className="mb-3"><Form.Label>Skills</Form.Label>
              <Form.Control name="Skills" value={profile.Skills} onChange={onChange} /></Form.Group>
            <Form.Check type="checkbox" className="mb-3" label="Active" checked={profile.IsActive} onChange={(e)=> setProfile(p=>({...p, IsActive: e.target.checked}))} />
            <Button type="submit" variant="primary" className="w-100">Save Profile</Button>
          </Form>
        </Card.Body></Card>
      </Col>
      <Col md={7}>
        <Card><Card.Body>
          <Card.Title>Search Jobs</Card.Title>
          <InputGroup className="mb-3"><Form.Control placeholder="Search by job title..." value={query} onChange={(e)=>setQuery(e.target.value)} /></InputGroup>
          <ListGroup>
            {filtered.map(job => (
              <ListGroup.Item key={job.JobID || job.id}>
                <div className="d-flex justify-content-between align-items-center">
                  <div><div className="fw-bold">{job.Title || job.title}</div>
                    <div className="text-muted small">{job.Location || job.location} {(job.Industry || job.industry) ? "• " + (job.Industry || job.industry) : ""}</div>
                  </div>
                  <Button size="sm" onClick={()=>apply(job)}>Apply</Button>
                </div>
              </ListGroup.Item>
            ))}
            {filtered.length===0 && <div className="text-center text-muted p-3">No jobs found.</div>}
          </ListGroup>
        </Card.Body></Card>
      </Col>
    </Row>
  </Container>);
};
export default JobSeekerDashboard;