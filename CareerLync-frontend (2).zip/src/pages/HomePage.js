import React from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
const HomePage = () => {
  const nav = useNavigate();
  return (<Container className="mt-5">
    <Row className="justify-content-center">
      <Col md={8}>
        <Card className="p-4 text-center">
          <h1 className="mb-3">Welcome to CareerLync</h1>
          <p className="text-muted">Find your next opportunity or hire great talent.</p>
          <div className="d-flex justify-content-center gap-3">
            <Button variant="primary" onClick={()=>nav("/login")}>Login</Button>
            <Button variant="success" onClick={()=>nav("/register")}>Get Started</Button>
          </div>
        </Card>
      </Col>
    </Row>
  </Container>);
};
export default HomePage;