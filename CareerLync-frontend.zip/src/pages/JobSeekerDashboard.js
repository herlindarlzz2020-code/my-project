import React, { useState, useEffect } from "react";
import { Container, Card, Button, Form, ListGroup } from "react-bootstrap";
import api from "../api";

const JobSeekerDashboard = () => {
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);

  const fetchJobs = async () => {
    const res = await api.get("/Jobs");
    setJobs(res.data);
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const applyToJob = async (jobId) => {
    await api.post("/Applications", { jobId });
    alert("Applied successfully!");
  };

  return (
    <Container className="mt-4">
      <Card>
        <Card.Body>
          <h4>Available Jobs</h4>
          <ListGroup>
            {jobs.map((job) => (
              <ListGroup.Item key={job.id}>
                <strong>{job.title}</strong> - {job.description}
                <Button
                  variant="success"
                  size="sm"
                  className="float-end"
                  onClick={() => applyToJob(job.id)}
                >
                  Apply
                </Button>
              </ListGroup.Item>
            ))}
          </ListGroup>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default JobSeekerDashboard;
