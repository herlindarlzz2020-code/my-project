import React, { useState, useEffect } from "react";
import { Container, Card, Button, Form, ListGroup } from "react-bootstrap";
import api from "../api";

const EmployerDashboard = () => {
  const [jobs, setJobs] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const fetchJobs = async () => {
    const res = await api.get("/Jobs");
    setJobs(res.data);
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const handlePostJob = async (e) => {
    e.preventDefault();
    await api.post("/Jobs", { title, description });
    setTitle("");
    setDescription("");
    fetchJobs();
  };

  return (
    <Container className="mt-4">
      <Card className="mb-4">
        <Card.Body>
          <h4>Post a Job</h4>
          <Form onSubmit={handlePostJob}>
            <Form.Group className="mb-2">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </Form.Group>
            <Button type="submit" variant="primary">
              Post Job
            </Button>
          </Form>
        </Card.Body>
      </Card>

      <Card>
        <Card.Body>
          <h4>Your Jobs</h4>
          <ListGroup>
            {jobs.map((job) => (
              <ListGroup.Item key={job.id}>
                <strong>{job.title}</strong> - {job.description}
              </ListGroup.Item>
            ))}
          </ListGroup>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default EmployerDashboard;
