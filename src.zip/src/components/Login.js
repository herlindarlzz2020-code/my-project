// import { useState } from "react"
// import { Link, useNavigate } from "react-router-dom"
// import { Container, Form, Button, Row, Col, Nav } from "react-bootstrap";
// import axios from "axios";
// import jwtDecode from "jwt-decode";


// function Login() {
//   const navigate = useNavigate();
//   const [userName, setUserName] = useState("");
//   const [password, setPassword] = useState("");

//   const login = async () => {
//     try {
//       if (userName === 'admin' && password === 'adminpwd') {
//         navigate("/admindashboard");
//         return;
//       }

//       const response = await axios.post("https://localhost:7278/api/vistora/login", {
//         Username: userName,
//         Password: password
//       });

//       console.log("Login response:", response.data);

//       const { accessToken, refreshToken, userId, user } = response.data;

//       const finalUserId = userId || user?.userId;

//       if (!accessToken) {
//         console.error("Access token missing from response:", response.data);
//         alert("Login failed: Invalid token from server.");
//         return;
//       }

//       localStorage.setItem("accessToken", accessToken);
//       localStorage.setItem("refreshToken", refreshToken);
//       localStorage.setItem("userId",finalUserId);

//       console.log("Saved userId:",finalUserId);
//       const tokenPayload = JSON.parse(atob(accessToken.split('.')[1]));
//       console.log("Decoded token payload:", tokenPayload);

//       // const role = tokenPayload["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];

//       const role =
//         tokenPayload["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"] ||
//         tokenPayload["role"] ||
//         tokenPayload["Role"] ||
//         tokenPayload["roles"]?.[0]; // if it's an array

//       console.log("Extracted role:", role);

//       if (role === "Customer") {
//         navigate("/customerdashboard");
//       } else if (role === "HotelOwner") {
//         navigate("/hotelownerdashboard");
//       } else {
//         alert("Unknown role. Access denied.");
//       }


//     } catch (error) {
//       console.error("Login failed:", error.response?.data || error.message);
//       alert("Invalid credentials or server error.");
//     }

//   };
//   return (
//     <center style={{ color: "#096B68" }}>
//       <Container className="d-flex justify-content-center align-items-center vh-100" >
//         <Row style={{ marginTop: '-100px', padding: '8px', borderRadius: '5px', border: "2px solid #096B68", backgroundColor: "#90D1CA" }}>
//           <Col>
//             <h2 className="text-center mb-4">Login</h2>
//             <Form>
//               <Form.Group as={Row} className="mb-3" controlId="formHorizontalUsername">
//                 <Form.Label column sm={3} style={{ fontWeight: "bold" }}>Username</Form.Label>
//                 <Col sm={9}>
//                   <Form.Control
//                     type="text"
//                     placeholder="Enter username"
//                     value={userName}
//                     onChange={(e) => setUserName(e.target.value)}
//                     style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
//                   />
//                 </Col>
//               </Form.Group>

//               <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
//                 <Form.Label column sm={3} style={{ fontWeight: "bold" }}>Password</Form.Label>
//                 <Col sm={9}>
//                   <Form.Control
//                     type="password"
//                     placeholder="Enter password"
//                     value={password}
//                     onChange={(e) => setPassword(e.target.value)}
//                     style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
//                   />
//                 </Col>
//               </Form.Group>

//               <div className="d-grid gap-2" style={{ textAlign: 'center' }}>
//                 <Button style={{ backgroundColor: "#096B68", fontWeight: "bold" }} onClick={login}>
//                   Login
//                 </Button>
//               </div>

//               <div className="mt-3 text-center">
//                 <Nav.Link as={Link} to="/forgetpass" style={{ fontWeight: "bold" }}>Forget Password</Nav.Link>
//               </div>

//               <div className="mt-3 text-center">
//                 <Nav.Link as={Link} to="/" style={{ fontWeight: "bold" }}>Create new Account</Nav.Link>
//               </div>
//             </Form>
//           </Col>
//         </Row>
//       </Container>
//     </center>
//   );
// }
// export default Login


import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Container, Form, Button, Row, Col, Nav } from "react-bootstrap";
import axios from "axios";
import {jwtDecode} from "jwt-decode";

function Login() {
  const navigate = useNavigate();
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");

  const login = async () => {
    try {
      if (userName === "admin" && password === "adminpwd") {
        navigate("/admindashboard");
        return;
      }

      const response = await axios.post("https://localhost:7278/api/vistora/login", {
        Username: userName,
        Password: password,
      });

      console.log("Login response:", response.data);

      const { accessToken, refreshToken } = response.data;

      if (!accessToken) {
        console.error("Access token missing from response:", response.data);
        alert("Login failed: Invalid token from server.");
        return;
      }

      // Save tokens
      localStorage.setItem("accessToken", accessToken);
      localStorage.setItem("refreshToken", refreshToken);

      // Decode token to get userId
      const tokenPayload = jwtDecode(accessToken);
      console.log("Decoded token payload:", tokenPayload);

      const userId = tokenPayload.unique_name; // 👈 comes from JWT
      localStorage.setItem("userId", userId);
      console.log("Saved userId:", userId);

      // Extract role safely
      const role =
        tokenPayload["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"] ||
        tokenPayload["role"] ||
        tokenPayload["Role"] ||
        tokenPayload["roles"]?.[0];

      console.log("Extracted role:", role);

      if (role === "Customer") {
        navigate("/customerdashboard");
      } else if (role === "HotelOwner") {
        navigate("/hotelownerdashboard");
      } else {
        alert("Unknown role. Access denied.");
      }
    } catch (error) {
      console.error("Login failed:", error.response?.data || error.message);
      alert("Invalid credentials or server error.");
    }
  };

  return (
    <center style={{ color: "#096B68" }}>
      <Container className="d-flex justify-content-center align-items-center vh-100">
        <Row
          style={{
            marginTop: "-100px",
            padding: "8px",
            borderRadius: "5px",
            border: "2px solid #096B68",
            backgroundColor: "#90D1CA",
          }}
        >
          <Col>
            <h2 className="text-center mb-4">Login</h2>
            <Form>
              <Form.Group as={Row} className="mb-3" controlId="formHorizontalUsername">
                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                  Username
                </Form.Label>
                <Col sm={9}>
                  <Form.Control
                    type="text"
                    placeholder="Enter username"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                  />
                </Col>
              </Form.Group>

              <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                  Password
                </Form.Label>
                <Col sm={9}>
                  <Form.Control
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                  />
                </Col>
              </Form.Group>

              <div className="d-grid gap-2" style={{ textAlign: "center" }}>
                <Button style={{ backgroundColor: "#096B68", fontWeight: "bold" }} onClick={login}>
                  Login
                </Button>
              </div>

              <div className="mt-3 text-center">
                <Nav.Link as={Link} to="/forgetpass" style={{ fontWeight: "bold" }}>
                  Forget Password
                </Nav.Link>
              </div>

              <div className="mt-3 text-center">
                <Nav.Link as={Link} to="/" style={{ fontWeight: "bold" }}>
                  Create new Account
                </Nav.Link>
              </div>
            </Form>
          </Col>
        </Row>
      </Container>
    </center>
  );
}

export default Login;
