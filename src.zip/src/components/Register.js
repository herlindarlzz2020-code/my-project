import React, { useState } from "react";
import { Container, Row, Col, Form, Button, Nav } from "react-bootstrap";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";

const Register = () => {
    const navigate = useNavigate();

    const register = async () => {

        const userData = {
            username: formData.username,
            Name: formData.fullName,
            email: formData.email,
            password: formData.password,
            phoneNumber: formData.phoneNumber,
            age: formData.age,
            role: formData.role
        }
        if (!formData.username || !formData.password || !formData.role || !formData.phoneNumber || !formData.email || !formData.age || !formData.fullName) {
            alert("Please fill in all fields.");
            return;
        }

        try {
            const response = await axios.post("https://localhost:7278/api/vistora/register", userData, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            alert(response.data); // "Customer Account created successfully"
            navigate('/login');
        } catch (error) {
            if (error.response) {
                console.error("API error:", error.response.data);
                alert("Failed to register: " + JSON.stringify(error.response.data));
            } else {
                console.error("Network error:", error.message);
                alert("Network error. Please try again later.");
            }
        }
    };

    const [formData, setFormData] = useState({
        username: "",
        fullName: "",
        email: "",
        password: "",
        phoneNumber: "",
        age: "",
        role: "Customer", // default role
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    return (
        <center style={{ color: "#096B68" }}>
            <Container className="d-flex justify-content-center align-items-center vh-100">
                <Row
                    style={{
                        marginTop: "-100px",
                        padding: "16px",
                        borderRadius: "5px",
                        border: "2px solid #096B68",
                        backgroundColor: "#90D1CA",
                    }}
                >
                    <Col>
                        <h3 className="text-center mb-4">Register</h3>
                        <Form>
                            {/** Full Name */}
                            <Form.Group as={Row} className="mb-3">
                                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                                    Name
                                </Form.Label>
                                <Col sm={9}>
                                    <Form.Control
                                        type="text"
                                        name="fullName"
                                        placeholder="Enter Name"
                                        value={formData.fullName}
                                        onChange={handleChange}
                                        style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                    />
                                </Col>
                            </Form.Group>

                            {/** Email */}
                            <Form.Group as={Row} className="mb-3">
                                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                                    Email
                                </Form.Label>
                                <Col sm={9}>
                                    <Form.Control
                                        type="email"
                                        name="email"
                                        placeholder="Enter Email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                    />
                                </Col>
                            </Form.Group>

                            {/** Username */}
                            <Form.Group as={Row} className="mb-3">
                                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                                    Username
                                </Form.Label>
                                <Col sm={9}>
                                    <Form.Control
                                        type="text"
                                        name="username"
                                        placeholder="Enter Username"
                                        value={formData.username}
                                        onChange={handleChange}
                                        style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                    />
                                </Col>
                            </Form.Group>

                            {/** Password */}
                            <Form.Group as={Row} className="mb-3">
                                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                                    Password
                                </Form.Label>
                                <Col sm={9}>
                                    <Form.Control
                                        type="password"
                                        name="password"
                                        placeholder="Enter Password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                    />
                                </Col>
                            </Form.Group>

                            {/** Phone Number */}
                            <Form.Group as={Row} className="mb-3">
                                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                                    Phone
                                </Form.Label>
                                <Col sm={9}>
                                    <Form.Control
                                        type="text"
                                        name="phoneNumber"
                                        placeholder="Enter Phone Number"
                                        value={formData.phoneNumber}
                                        onChange={handleChange}
                                        style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                    />
                                </Col>
                            </Form.Group>

                            {/** Age */}
                            <Form.Group as={Row} className="mb-3">
                                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                                    Age
                                </Form.Label>
                                <Col sm={9}>
                                    <Form.Control
                                        type="number"
                                        name="age"
                                        placeholder="Enter Age"
                                        value={formData.age}
                                        onChange={handleChange}
                                        style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                    />
                                </Col>
                            </Form.Group>

                            {/** Role */}
                            <Form.Group as={Row} className="mb-3">
                                <Form.Label column sm={3} style={{ fontWeight: "bold" }}>
                                    Role
                                </Form.Label>
                                <Col sm={9}>
                                    <Form.Select
                                        name="role"
                                        value={formData.role}
                                        onChange={handleChange}
                                        style={{ backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                    >
                                        <option value="Customer">Customer</option>
                                        <option value="HotelOwner">HotelOwner</option>
                                    </Form.Select>
                                </Col>
                            </Form.Group>

                            <div className="d-grid gap-2" style={{ textAlign: "center" }}>
                                <Button
                                    style={{ backgroundColor: "#096B68", fontWeight: "bold" }}
                                    onClick={register}
                                >
                                    Register
                                </Button>
                            </div>

                            <div className="mt-3 text-center">
                                <Nav.Link as={Link} to="/login" style={{ fontWeight: "bold" }}>
                                    Already Have Account
                                </Nav.Link>
                            </div>
                        </Form>
                    </Col>
                </Row>
            </Container>
        </center>
    );
};

export default Register;
