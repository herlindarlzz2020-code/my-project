// src/components/CustomerHome.js
import React from "react";
import { Carousel } from "react-bootstrap";
import image1 from '../../Images/image1.jpg';
import image2 from '../../Images/image2.jpg';
import image3 from '../../Images/image3.webp';
import image4 from '../../Images/image4.jpg';
import image5 from '../../Images/image5.jpg';
import image6 from '../../Images/image6.avif';
import image7 from '../../Images/image7.jpg';
import image8 from '../../Images/image8.jpg';

const CustomerHome = () => {
  return (
    <>
      <h3 style={{color:"#096B68",marginTop:"10px",fontStyle:"italic"}}>Welcome to Vistora</h3>
      <Carousel className="mt-3">
        <Carousel.Item>
          <img className="d-block w-100" src={image1} alt="Slide 1" />
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={image2} alt="Slide 2" />
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={image3} alt="Slide 3" />
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={image4} alt="Slide 4" />
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={image5} alt="Slide 5" />
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={image6} alt="Slide 6" />
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={image7} alt="Slide 7" />
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={image8} alt="Slide 8" />
        </Carousel.Item>
      </Carousel>
    </>
  );
};

export default CustomerHome;
