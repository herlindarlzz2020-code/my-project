// src/components/BookingHistory.js
import { useEffect, useState } from "react";
import { Table, Container, Spinner, Alert } from "react-bootstrap";
import axios from "axios";
import CustomerNavbar from "./CustomerNavbar";

const BookingHistory = () => {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const token = localStorage.getItem("accessToken");
  const userId = localStorage.getItem("userId");

  useEffect(() => {
    const fetchReservations = async () => {
      try {
        const response = await axios.get(
          `https://localhost:7278/api/Reservation/GetReservationsByUser/${userId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setReservations(response.data);
      } catch (err) {
        setError("Failed to fetch reservations");
      } finally {
        setLoading(false);
      }
    };

    if (userId && token) {
      fetchReservations();
    } else {
      setError("User not logged in");
      setLoading(false);
    }
  }, [userId, token]);

  if (loading) {
    return (
      <Container className="text-center mt-4">
        <Spinner animation="border" variant="success" />
      </Container>
    );
  }

  if (error) {
    return (
      <Container className="mt-4">
        <Alert variant="danger">{error}</Alert>
      </Container>
    );
  }

  return (
    <>
    <CustomerNavbar/>
    <Container className="mt-4">
      <h2 style={{ color: "#096B68", fontWeight: "bold" }}>My Booking History</h2>
      {reservations.length === 0 ? (
        <Alert variant="info" className="mt-3">
          No reservations found.
        </Alert>
      ) : (
        <Table striped bordered hover className="mt-3 shadow-sm">
          <thead style={{ backgroundColor: "#096B68", color: "white" }}>
            <tr>
              <th>#</th>
              <th>Hotel Name</th>
              <th>Room Type</th>
              <th>Guests</th>
              <th>Check-In</th>
              <th>Check-Out</th>
              <th>Booking Date</th>
              <th>Total Price</th>
            </tr>
          </thead>
          <tbody>
            {reservations.map((res, index) => (
              <tr key={res.reservationId}>
                <td>{index + 1}</td>
                <td>{res.hotelName}</td>
                <td>{res.roomType}</td>
                <td>{res.numberOfGuests}</td>
                <td>{new Date(res.checkInDate).toLocaleDateString()}</td>
                <td>{new Date(res.checkOutDate).toLocaleDateString()}</td>
                <td>{new Date(res.bookingDate).toLocaleDateString()}</td>
                <td>₹{res.totalPrice}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Container>
    </>
  );
};

export default BookingHistory;
