import {useNavigate } from "react-router";
import CustomerHome from "./CustomerHome";
import CustomerNavbar from "./CustomerNavbar";


const CustomerDashboard = () => {
    const navigate = useNavigate();
    

    return (
        <>
            <CustomerNavbar/>
            <CustomerHome/>
        </>
    )
}
export default CustomerDashboard