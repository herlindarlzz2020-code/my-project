import { useEffect, useState } from "react";
import { Form, Container, Row, Col, Spinner, Card } from "react-bootstrap";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import CustomerDashboard from "./CustomerDashboard";


const HotelSearchPage = () => {
    const navigate = useNavigate();
    const token = localStorage.getItem("accessToken");
    const [hotels, setHotels] = useState([]);
    const [selectedHotelValue, setSelectedHotelValue] = useState("");
    const [selectedAddressValue, setSelectedAddressValue] = useState("");
    const [selectedCityValue, setSelectedCityValue] = useState("");

    const [loading, setLoading] = useState(true);

    useEffect(() => {
        axios
            .get("https://localhost:7278/api/customer/GetAllHotels", {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            })
            .then((response) => {
                console.log("Hotels:", response.data);
                setHotels(response.data);
                setLoading(false);
            })
            .catch((error) => {
                console.error("Error fetching hotels", error);
                setLoading(false);
            });
    }, [token]);

    const filteredHotels = hotels.filter((hotel) => {
        const matchesHotel = selectedHotelValue
            ? hotel.name.toLowerCase().includes(selectedHotelValue.toLowerCase())
            : true;
        const matchesAddress = selectedAddressValue
            ? hotel.address.toLowerCase().includes(selectedAddressValue.toLowerCase())
            : true;
        const matchesCity = selectedCityValue
            ? hotel.location.toLowerCase().includes(selectedCityValue.toLowerCase())
            : true;

        return matchesHotel && matchesAddress && matchesCity;
    });


    return (
        <>
            <CustomerDashboard />
            <Container className="mt-4">
                <Row className="justify-content-center">
                    <Col md={6}>
                        <h4 className="mb-4 text-center" style={{ color: "#096B68" }}>Book your stay with <i style={{ color: "#239BA7", fontWeight: "bolder" }}>Vistora</i></h4>

                        {loading ? (
                            <div className="text-center">
                                <Spinner animation="border" variant="primary" />
                            </div>
                        ) : (
                            <>
                                <Form>
                                    <Form.Group controlId="hotelSelect" className="mb-3">
                                        <Form.Label style={{ color: "#096B68", fontWeight: "bolder", fontSize: "large" }}>Select Hotel</Form.Label>
                                        <Form.Control
                                            list="hotelsList"
                                            placeholder="Type to search..."
                                            value={selectedHotelValue}
                                            onChange={(e) => setSelectedHotelValue(e.target.value)}
                                            style={{ boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px", backgroundColor: "#90D1CA", border: "2px solid #096B68" }}

                                        />
                                        <datalist id="hotelsList">
                                            {hotels.map((hotel) => (
                                                <option key={hotel.hotelId} value={hotel.name} />
                                            ))}
                                        </datalist>
                                    </Form.Group>

                                    <Form.Group controlId="addressSelect" className="mb-3">
                                        <Form.Label style={{ color: "#096B68", fontWeight: "bolder", fontSize: "large" }}>Address</Form.Label>
                                        <Form.Control
                                            list="hotelAddress"
                                            placeholder="Type to search..."
                                            value={selectedAddressValue}
                                            onChange={(e) => setSelectedAddressValue(e.target.value)}
                                            style={{ boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px", backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                        />
                                        <datalist id="hotelAddress">
                                            {hotels.map((hotel) => (
                                                <option key={hotel.hotelId} value={hotel.address} />
                                            ))}
                                        </datalist>
                                    </Form.Group>

                                    <Form.Group controlId="citySelect" className="mb-3">
                                        <Form.Label style={{ color: "#096B68", fontWeight: "bolder", fontSize: "large" }}>City</Form.Label>
                                        <Form.Control
                                            list="hotelCity"
                                            placeholder="Type to search..."
                                            value={selectedCityValue}
                                            onChange={(e) => setSelectedCityValue(e.target.value)}
                                            style={{ boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px", backgroundColor: "#90D1CA", border: "2px solid #096B68" }}
                                        />
                                        <datalist id="hotelCity">
                                            {hotels.map((hotel) => (
                                                <option key={hotel.hotelId} value={hotel.location} />
                                            ))}
                                        </datalist>
                                    </Form.Group>

                                </Form>

                                <Row className="mt-4">
                                    {filteredHotels.length > 0 ? (
                                        filteredHotels.map((hotel) => (
                                            <Col md={6} key={hotel.hotelId} className="mb-3">
                                                <Card
                                                    style={{ backgroundColor: '#90D1CA', color: '#096B68', border: '2px solid #096B68' }}
                                                    onClick={() => navigate(`/reservation/${hotel.hotelId}`)}
                                                >
                                                    <Card.Body>
                                                        <Card.Title>
                                                            <i style={{ fontWeight: 'bold' }}>{hotel.name}</i>
                                                        </Card.Title>
                                                        <Card.Text>
                                                            <strong>Address: </strong> {hotel.address}
                                                            <br />
                                                            <strong>City: </strong> {hotel.location}
                                                            <br />
                                                            <strong>Contact: </strong> {hotel.contactNumber}
                                                            <br />
                                                            <strong>Description: </strong> {hotel.description}
                                                            <br />
                                                            <strong>Amenities: </strong> {hotel.amenities}
                                                        </Card.Text>
                                                    </Card.Body>
                                                </Card>
                                            </Col>
                                        ))
                                    ) : (
                                        <div className="text-center text-danger fw-bold">
                                            No results found
                                        </div>
                                    )}

                                </Row>
                            </>
                        )}

                    </Col>
                </Row>
            </Container>
        </>
    );
};

export default HotelSearchPage;
