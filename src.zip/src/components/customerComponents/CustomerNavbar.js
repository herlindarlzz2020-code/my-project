import react, { useEffect, useState } from "react"
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import {Button} from "react-bootstrap";
import {Nav} from 'react-bootstrap';
import { Link, useNavigate } from "react-router";
const CustomerNavbar = () =>{
    const navigate = useNavigate();
    const logout = () => {
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        localStorage.removeItem("userId");
        navigate("/login");
    };
return(
    <>
    <Navbar expand="lg" style={{backgroundColor:"#90D1CA", border:"2px solid #096B68"}}>
                <Container>
                    <Navbar.Brand href="#home" style={{color:"#096B68",fontWeight:"bolder"}}>Customer Dashboard</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            <Nav.Link as={Link} to="/customerdashboard" style={{color:"#096B68",fontWeight:"bold"}}>Home</Nav.Link>
                            <Nav.Link as={Link} to="/hotelsearch" style={{color:"#096B68",fontWeight:"bold"}}>Make Booking</Nav.Link>
                            <Nav.Link as={Link} to="/bookinghistory" style={{color:"#096B68",fontWeight:"bold"}}>Bookings</Nav.Link>
                            <Nav.Link as={Button} onClick={logout} style={{color:"#096B68",fontWeight:"bold"}}>Logout</Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
    </>
)
}
export default CustomerNavbar