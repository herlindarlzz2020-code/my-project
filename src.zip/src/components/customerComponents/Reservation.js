// import { useEffect, useState } from "react";
// import { useParams, useNavigate } from "react-router-dom";
// import { Container, Row, Col, Card, Form } from "react-bootstrap";
// import axios from "axios";

// const Reservation = () => {
//   const { hotelId } = useParams();
//   const [rooms, setRooms] = useState([]);
//   const [reservation, setReservation] = useState({
//     userId: localStorage.getItem("userId"), // from login
//     roomId: 0,
//     checkInDate: "",
//     checkOutDate: "",
//     noOfAdults: 1,
//     noOfChildren: 0,
//   });
//   const token = localStorage.getItem("accessToken");
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchRooms = async () => {
//       try {
//         const res = await axios.get(
//           `https://localhost:7278/api/Room/hotel/${hotelId}`,
//           { headers: { Authorization: `Bearer ${token}` } }
//         );
//         setRooms(res.data);
//       } catch (err) {
//         console.error("Error fetching rooms", err);
//       }
//     };
//     fetchRooms();
//   }, [hotelId, token]);

//   const handleReservation = async () => {
//     try {
//       await axios.post("https://localhost:7278/api/customer/reservations", reservation, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       alert("Reservation successful!");
//       navigate("/dashboard"); // redirect after booking
//     } catch (err) {
//       console.error("Error creating reservation", err);
//       alert("Failed to reserve room");
//     }
//   };

//   return (
//     <Container className="mt-4">
//       <h3 style={{ color: "#096B68", fontWeight: "bold" }}>
//         Available Rooms
//       </h3>
//       <Row>
//         {rooms.map((room) => (
//           <Col md={4} key={room.roomId} className="mb-4">
//             <Card
//               className={`shadow-sm ${
//                 reservation.roomId === room.roomId ? "border border-success" : ""
//               }`}
//               style={{ cursor: "pointer" }}
//               onClick={() =>
//                 setReservation({ ...reservation, roomId: room.roomId })
//               }
//             >
//               <Card.Body>
//                 <Card.Title>{room.bedType}</Card.Title>
//                 <Card.Text>
//                   <b>Room Id:</b> {room.roomId} <br/>
//                   <b>Max Occupancy:</b> {room.maxPeople} <br />
//                   <b>AC Available:</b>{" "}
//                   {room.acAvailability ? "Yes" : "No"} <br />
//                   <b>Status:</b>{" "}
//                   {room.availabilityStatus ? "Available" : "Not Available"}
//                 </Card.Text>
//               </Card.Body>
//             </Card>
//           </Col>
//         ))}
//       </Row>

//       {reservation.roomId !== 0 && (
//         <Form className="mt-4">
//           <Row>
//             <Col md={6}>
//               <Form.Group className="mb-3">
//                 <Form.Label>Check-In Date</Form.Label>
//                 <Form.Control
//                   type="date"
//                   value={reservation.checkInDate}
//                   onChange={(e) =>
//                     setReservation({
//                       ...reservation,
//                       checkInDate: e.target.value,
//                     })
//                   }
//                 />
//               </Form.Group>
//             </Col>
//             <Col md={6}>
//               <Form.Group className="mb-3">
//                 <Form.Label>Check-Out Date</Form.Label>
//                 <Form.Control
//                   type="date"
//                   value={reservation.checkOutDate}
//                   onChange={(e) =>
//                     setReservation({
//                       ...reservation,
//                       checkOutDate: e.target.value,
//                     })
//                   }
//                 />
//               </Form.Group>
//             </Col>
//           </Row>

//           <Row>
//             <Col md={6}>
//               <Form.Group className="mb-3">
//                 <Form.Label>No of Adults</Form.Label>
//                 <Form.Control
//                   type="number"
//                   min="1"
//                   value={reservation.noOfAdults}
//                   onChange={(e) =>
//                     setReservation({
//                       ...reservation,
//                       noOfAdults: e.target.value,
//                     })
//                   }
//                 />
//               </Form.Group>
//             </Col>
//             <Col md={6}>
//               <Form.Group className="mb-3">
//                 <Form.Label>No of Children</Form.Label>
//                 <Form.Control
//                   type="number"
//                   min="0"
//                   value={reservation.noOfChildren}
//                   onChange={(e) =>
//                     setReservation({
//                       ...reservation,
//                       noOfChildren: e.target.value,
//                     })
//                   }
//                 />
//               </Form.Group>
//             </Col>
//           </Row>

//           <button
//             onClick={handleReservation}
//             type="button"
//             className="btn"
//             style={{
//               backgroundColor: "#096B68",
//               color: "white",
//               fontWeight: "bold",
//             }}
//           >
//             Confirm Reservation
//           </button>
//         </Form>
//       )}
//     </Container>
//   );
// };

// export default Reservation;

import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Container, Row, Col, Card, Form } from "react-bootstrap";
import axios from "axios";
import CustomerNavbar from "./CustomerNavbar";

const Reservation = () => {
  const { hotelId } = useParams();
  const [rooms, setRooms] = useState([]);
  const [reservation, setReservation] = useState({
    userId: localStorage.getItem("userId"), // from login
    roomId: 0,
    checkInDate: "",
    checkOutDate: "",
    noOfAdults: 1,
    noOfChildren: 0,
  });
  const token = localStorage.getItem("accessToken");
  const navigate = useNavigate();

  // Fetch available rooms
  useEffect(() => {
    const fetchRooms = async () => {
      try {
        const res = await axios.get(
          `https://localhost:7278/api/Room/hotel/${hotelId}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setRooms(res.data);
      } catch (err) {
        console.error("Error fetching rooms", err);
      }
    };
    fetchRooms();
  }, [hotelId, token]);

  // Reservation Handler
  const handleReservation = async () => {
    const userId = localStorage.getItem("userId");

    if (!reservation.checkInDate || !reservation.checkOutDate) {
      alert("Please select check-in and check-out dates.");
      return;
    }

    if (new Date(reservation.checkOutDate) <= new Date(reservation.checkInDate)) {
      alert("Check-out date must be after check-in date.");
      return;
    }

    try {
      const payload = {
      userId: parseInt(userId),
      roomId: parseInt(reservation.roomId),
      checkInDate: new Date(reservation.checkInDate).toISOString(),
      checkOutDate: new Date(reservation.checkOutDate).toISOString(),
      noOfAdults: parseInt(reservation.noOfAdults),
      noOfChildren: parseInt(reservation.noOfChildren),
      };
      console.log("Payload" , payload);
      await axios.post(
        "https://localhost:7278/api/customer/reservations",
        payload,
        // {
        //   ...reservation,
        //   noOfAdults: parseInt(reservation.noOfAdults),
        //   noOfChildren: parseInt(reservation.noOfChildren),
        // },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert("Reservation successful!");
      navigate("/customerdashboard");
    } catch (err) {
      console.error("Error creating reservation", err);
      alert("Failed to reserve room");
    }
  };

  return (
    <>
    <CustomerNavbar/>
    <Container className="mt-4">
      <h3 style={{ color: "#096B68", fontWeight: "bold" }}>Available Rooms</h3>
      <Row>
        {rooms.map((room) => (
          <Col md={4} key={room.roomId} className="mb-4">
            <Card
              className={`shadow-sm ${
                reservation.roomId === room.roomId ? "border border-success" : ""
              }`}
              style={{
                cursor: room.availabilityStatus ? "pointer" : "not-allowed",
                opacity: room.availabilityStatus ? 1 : 0.6,
              }}
              onClick={() =>
                room.availabilityStatus &&
                setReservation({ ...reservation, roomId: room.roomId })
              }
            >
              <Card.Body>
                <Card.Title>{room.bedType}</Card.Title>
                <Card.Text>
                  <b>Room Id:</b> {room.roomId} <br />
                  <b>Max Occupancy:</b> {room.maxPeople} <br />
                  <b>AC Available:</b>{" "}
                  {room.acAvailability ? "Yes" : "No"} <br />
                  <b>Status:</b>{" "}
                  {room.availabilityStatus ? "Available" : "Not Available"}
                </Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>

      {reservation.roomId !== 0 && (
        <Form className="mt-4">
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Check-In Date</Form.Label>
                <Form.Control
                  type="date"
                  min={new Date().toISOString().split("T")[0]}
                  value={reservation.checkInDate}
                  onChange={(e) =>
                    setReservation({ ...reservation, checkInDate: e.target.value })
                  }
                />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Check-Out Date</Form.Label>
                <Form.Control
                  type="date"
                  min={reservation.checkInDate || new Date().toISOString().split("T")[0]}
                  value={reservation.checkOutDate}
                  onChange={(e) =>
                    setReservation({ ...reservation, checkOutDate: e.target.value })
                  }
                />
              </Form.Group>
            </Col>
          </Row>

          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>No of Adults</Form.Label>
                <Form.Control
                  type="number"
                  min="1"
                  value={reservation.noOfAdults}
                  onChange={(e) =>
                    setReservation({
                      ...reservation,
                      noOfAdults: parseInt(e.target.value),
                    })
                  }
                />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>No of Children</Form.Label>
                <Form.Control
                  type="number"
                  min="0"
                  value={reservation.noOfChildren}
                  onChange={(e) =>
                    setReservation({
                      ...reservation,
                      noOfChildren: parseInt(e.target.value),
                    })
                  }
                />
              </Form.Group>
            </Col>
          </Row>

          <button
            onClick={handleReservation}
            type="button"
            className="btn"
            disabled={
              !reservation.checkInDate ||
              !reservation.checkOutDate ||
              !reservation.roomId
            }
            style={{
              backgroundColor: "#096B68",
              color: "white",
              fontWeight: "bold",
            }}
          >
            Confirm Reservation
          </button>
        </Form>
      )}
    </Container>
    </>
  );
};

export default Reservation;
