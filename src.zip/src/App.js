import './App.css';
import { Route, Routes } from 'react-router';
import Register from './components/Register';
import Login from './components/Login';
import CustomerDashboard from './components/customerComponents/CustomerDashboard';
import CustomerHome from './components/customerComponents/CustomerHome';
import HotelSearchPage from './components/customerComponents/HotelSearchPage';
import Reservation from './components/customerComponents/Reservation';
import CustomerNavbar from './components/customerComponents/CustomerNavbar';
import BookingHistory from './components/customerComponents/BookingHistory';

function App() {
  return (
    <center>
      <Routes>
        <Route path="/" element={<Register/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/customerdashboard' element={<CustomerDashboard/>}/>
        <Route path='/customerhome' element={<CustomerHome/>}/>
        <Route path='/hotelsearch' element={<HotelSearchPage/>}/>
        <Route path='/reservation/:hotelId' element={<Reservation/>}/>
        <Route path='/customernavbar' element={<CustomerNavbar/>}/>
        <Route path='/bookinghistory' element={<BookingHistory/>}/>
      </Routes>
    </center>
  );
}

export default App;
